#ifndef MENU_HPP_
#define MENU_HPP_

#include <string>
#include <sstream>

#include <ncurses.h>
#include <menu.h>

#define ARRAY_SIZE(a)   (sizeof(a) - sizeof(a[0]))

using namespace std;

class Menu {
 public:
    Menu(const char ** choices, unsigned n_choices);
    ~Menu();

    // getters and setters
    MENU * getParent(void);
    ITEM * getCurrentItem(void);
    string getCurrentItemName(void);
    WINDOW * getMenuWin(void);
    WINDOW * getSubWin(void);
    int getScale(unsigned * rows, unsigned * columns);

    int postMenu(void);
    int unpostMenu(void);

    int setMenuWin(WINDOW * win);
    int setMenuSubWin(WINDOW * subwin);
    int setMenuSubWin(size_t h, size_t w, unsigned y, unsigned x);
    int setMenuMark(string mark);

    string handleKeys(void);

 private:
  MENU * parent;
  ITEM ** choices;
  ITEM * cur_item;
  unsigned nchoices;

};

#endif /* end of include guard: MENU_HPP_ */
